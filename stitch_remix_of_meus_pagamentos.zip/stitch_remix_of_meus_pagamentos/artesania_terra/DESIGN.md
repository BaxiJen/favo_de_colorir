# Design System Strategy: Artisanal Modernism

## 1. Overview & Creative North Star
The Creative North Star for this system is **"The Digital Atelier."** 

Unlike standard e-commerce or utility apps that rely on rigid grids and clinical borders, this design system treats the mobile screen as a curated tabletop in a ceramic studio. We are moving away from "template" UI by embracing **Tactile Minimalist** principles: high-contrast typography scales, intentional asymmetry that mimics hand-placed objects, and a "No-Line" philosophy that uses light and depth rather than strokes to define space.

The goal is to make the user feel the "weight" of the ceramics through the screen. By utilizing the `epilogue` typeface for high-impact editorial moments and `manrope` for functional clarity, we create a dialogue between the raw, human craft of pottery and the precision of a premium digital experience.

---

## 2. Colors & Surface Philosophy
The palette is a sophisticated transition from earth to kiln. We use warm, honeyed tones to evoke a sense of welcoming warmth.

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders for sectioning or containment. 
Structure must be achieved through **Tonal Transitions**. To separate a header from a body, or a card from a background, use the shift from `surface` to `surface_container_low`. This creates a soft, "molded" look rather than a "cut-out" look.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of clay and paper. Use the following hierarchy for depth:
*   **Base Layer:** `surface` (#fff8f4) - The primary canvas.
*   **Secondary Sections:** `surface_container_low` (#fcf2ea) - For subtle grouping.
*   **Active Elements/Cards:** `surface_container` (#f6ece5) or `surface_container_highest` (#eae1d9) to pull items toward the user.

### The "Glass & Gradient" Rule
To elevate CTAs beyond a flat "button" feel, use a subtle linear gradient transitioning from `primary` (#8d4b00) to `primary_container` (#b15f00). For floating navigation or over-image overlays, use **Glassmorphism**:
*   **Fill:** `surface` at 70% opacity.
*   **Effect:** Backdrop-blur (12px–20px).
*   **Border:** Use a "Ghost Border" (see Section 4).

---

## 3. Typography
Typography is our primary tool for editorial character. We use a "High-Low" pairing strategy.

*   **The Artisanal Voice (Display & Headlines):** `epilogue`. This is your "handcrafted" signature. Use `display-lg` (3.5rem) with tight letter-spacing for hero moments to create a bold, boutique magazine feel.
*   **The Functional Voice (Body & Titles):** `manrope`. A clean, geometric sans-serif that ensures legibility.
*   **Intentional Hierarchy:** Always pair a `headline-lg` in `on_surface` with a `body-md` in `on_surface_variant` (#554336) to create depth through color, not just size.

---

## 4. Elevation & Depth
In this system, shadows are "Ambient Glows," not structural crutches.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface_container_lowest` (#ffffff) card sitting on a `surface_container` (#f6ece5) background provides a natural lift without a single drop shadow.
*   **Ambient Shadows:** If an element must float (e.g., a "Book Workshop" FAB), use a shadow with a blur of `24px`, an opacity of `6%`, and a tint of `primary` rather than pure black.
*   **The "Ghost Border" Fallback:** If accessibility requires a stroke, use `outline_variant` (#dbc2b0) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
*   **Primary:** Rounded `xl` (3rem), `primary` background with `on_primary` text. Use a subtle 2px inner-shadow on the top edge to give a "pressed clay" feel.
*   **Secondary:** `secondary_container` background with `on_secondary_container` text.
*   **Tertiary:** No background. Use `title-sm` typography with an underline in `primary` color, spaced `0.35rem` (spacing scale 1) below the text.

### Cards & Collections
*   **Rule:** Forbid divider lines. 
*   **Layout:** Use `spacing.6` (2rem) between cards. Content within cards should be anchored to the bottom-left to emphasize organic asymmetry. 
*   **Rounding:** Always use `lg` (2rem) or `xl` (3rem) for image containers to reinforce the "rounded pottery" aesthetic.

### Inputs & Forms
*   **Styling:** Use `surface_container_low` as the field background. No bottom border.
*   **States:** On focus, transition the background to `surface_container_highest` and add a `1px` Ghost Border in `primary`.

### Specialized Components: "The Kiln Gallery"
*   **Immersive Carousel:** A full-bleed horizontal scroll where images have varying aspect ratios (e.g., 4:5 mixed with 1:1) to create an artisanal, non-standard grid.
*   **The Texture Overlay:** A subtle noise texture (3% opacity) applied to `surface` layers to mimic the grain of unglazed ceramic.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins. For example, a `headline-lg` might have a left margin of `spacing.8` while the body text below it has a left margin of `spacing.12`.
*   **Do** prioritize high-quality photography. The UI is the "gallery wall," the pottery is the "art."
*   **Do** use `rounded-full` for chips and tags to mimic smooth pebbles.

### Don't
*   **Don't** use 1px solid black or grey lines. Ever.
*   **Don't** use "Standard" Material Design shadows. They are too aggressive for this organic palette.
*   **Don't** crowd the screen. If you are unsure, add `spacing.10` (3.5rem) of vertical white space. Silence is part of the design.
*   **Don't** use pure `#000000` for text. Use `on_surface` (#1f1b17) to keep the "warmth" intact.

---

## 7. Spacing & Rhythm
Use the Spacing Scale to create "Breathing Zones." 
*   **Mobile Gutters:** Standardize on `spacing.6` (2rem) for outer edges.
*   **Section Breaks:** Use `spacing.16` (5.5rem) to separate major content blocks. This ensures the "Minimalist" promise is kept, preventing the app from feeling like a cluttered marketplace.